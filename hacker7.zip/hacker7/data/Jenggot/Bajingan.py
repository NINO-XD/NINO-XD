Anak-anak dajal loh
Pikiran Lo Dec aee
