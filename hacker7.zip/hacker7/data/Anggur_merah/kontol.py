Zonk su asu
