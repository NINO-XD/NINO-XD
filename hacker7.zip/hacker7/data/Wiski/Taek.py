Bocah-bocah ga ada otak mau ngapain lohh
Picek asu anak kirek

