Kasihan Lo dek
Kena prank
